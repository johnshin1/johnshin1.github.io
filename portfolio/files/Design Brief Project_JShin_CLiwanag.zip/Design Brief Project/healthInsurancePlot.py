'''
Design Brief Project
John Shin & Christopher Liwanag
~Average percentage of people who don't have health insurance in the United
States by year
'''
import numpy as np
import os
import matplotlib.pyplot as plt

#defined variables and lists
percentage_list_2013 = []
percentage_list_2014 = []
percentage_list_2015 = []
percentages = []
average_2013 = 0
average_2014 = 0
average_2015 = 0

#go through each CSV file and take the data accordingly to be able to plot
for year in range(2013,2016):
    ###
    # Get the health insurance % by state data from CSV
    ###
    # Get the directory name for data files
    directory = os.path.dirname(os.path.abspath(__file__))
    # Build an absolute filename from directory + filename
    ## Import 2013 health insurance data % by state
    datafile = open(os.path.join(directory, 'uninsured americans '+str(year)+'.csv'),'r')
    data = datafile.readlines()
    #go through each percentage year lists and find the average
    
    if year == 2013:
        for line in data[4:56]:
            states_2013, percentage_2013 = line.split(",")
            percentage_list_2013.append(float(percentage_2013[1:-2]))
        for percent in percentage_list_2013:
            average_2013 += percent
        percentages.append(int(average_2013/len(percentage_list_2013)*100))
    
    elif year == 2014:
        for line in data[4:56]:
            states_2014, percentage_2014 = line.split(",")
            percentage_list_2014.append(float(percentage_2014[1:-2]))
        for percent in percentage_list_2014:
            average_2014 += percent
        percentages.append(int(average_2014/len(percentage_list_2014)*100))
    
    elif year == 2015:
        for line in data[4:56]:
            states_2015, percentage_2015 = line.split(",")
            percentage_list_2015.append(float(percentage_2015[1:-2]))
        for percent in percentage_list_2015:
            average_2015 += percent
        percentages.append(int(average_2015/len(percentage_list_2015)*100))

#take all the data and plot them onto a bar chart
n=len(percentages)
ind=np.arange(n)
width=0.35
fig, ax = plt.subplots(1,1)
ax.bar(ind, percentages, width, color="red")
ax.set_ylabel('Percentage of People')
ax.set_xlabel('Year')
ax.set_title('Average Percentage of People Without Healthcare In USA By Year', y=1.05)
plt.xticks(ind+width/2,("2013","2014","2015"))
fig.show()